/*
    To install express.js into your project folder, type:
    npm install --save express
    into the console.
    
    To install MySQL into your project folder, type:
    npm install --save mysql2
    into the console.

    NOTE: mysql2 is just a more recent version of mysql from what I understand.
    The --save command only saves whatever you're installing to that project folder. So if you later
    make a completely new project folder, you will have to type the above commands 
    into the console again.

*/

// imports express.js
const express = require('express');
// imports the database
// NOTE: the "./" in the string argument below signifies that the path is to a file on your computer
const db = require('./util/database');

const app = express();

// selects all fields from ./models/products.js and
// outputs them to the console
db.execute('SELECT * FROM products')
    .then(result => {
        console.log(result[0]);
    })
    .catch(err => {
        console.log(err);
    });


// listens for activity on port 3000
app.listen(3000);