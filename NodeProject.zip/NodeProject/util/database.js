/*
    NOTE: This file will not work unless you have the proper frameworks(?)
    installed. Please see project.js to install the appropriate frameworks(?).
*/


// imports mysql2
const mysql = require('mysql2');

// creates a pool of connections so that the server can handle multiple requests
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    database: '', // Enter your database folder name (if you have trouble with this let me know)
    password: '' // Enter your MySQL Workbench password
});
// exports the promise returned by pool.promise()
module.exports = pool.promise();
/*
    A Promise is an object representing the 
    eventual completion or failure of an asynchronous 
    operation.

    They allow for more concise code by eliminating the 
    need for callback functions.

    See the createAudioFileAsync() example in this link:
    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

    You can also see how a promise is handled in this program
    in project.js on lines 27 - 33.
*/