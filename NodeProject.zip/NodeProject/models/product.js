/*
    NOTE: This file will not work unless you have the proper frameworks(?)
    installed. Please see project.js to install the appropriate frameworks(?).
*/

// imports the MySQL database
const db = require('../util/database');

// creates and exports a Product object
module.exports = class Product {

    // Product object constructor
    constructor(id, title, imageUrl, description, price) {
        this.id = id;
        this.title = title;
        this.imageUrl = imageUrl;
        this.description = description;
        this.price = price;
    }
    // IGNORE THE SECTION BELOW

    // fetches all data from the database (to be later implemented
    // if our project requires us to make any controllers)
    // static fetchAll() {
    //     return db.execute('SELECT * FROM products');
    // }
}