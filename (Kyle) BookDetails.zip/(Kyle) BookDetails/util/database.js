
// imports mysql2
const mysql = require('mysql2');

// creates a pool of connections so that the server can handle multiple requests
const conn = mysql.createPool({
    host: 'localhost',
    user: 'root',
    database: 'group-7-db', // Enter your database folder name 
    password: 'CEN-4010!!!' // Enter your MySQL Workbench password
});

// exports database
module.exports = conn;
